import controller.LoginController;
import util.EntradaInvalidaException;

public class App {

    public static void main(String[] args) {
        try {
            if (args.length < 2) {
                System.out.println("Uso: java App <usuario> <senha>");
                return;
            }

            String usuario = args[0];
            String senha = args[1];

            LoginController controller = new LoginController();
            controller.processarLogin(usuario, senha);

        } catch (EntradaInvalidaException e) {
            System.err.println("Erro de validação: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Erro inesperado: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
