package repository;

import model.Usuario;
import service.HashService;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

public class UsuarioRepositorio {

    private static final Logger logger = Logger.getLogger(UsuarioRepositorio.class.getName());

    private static final Map<String, Usuario> usuarios = new HashMap<>();
    private final HashService hashService = new HashService();

    public UsuarioRepositorio() {
        // Simula criação de usuários dinâmicos (sem senhas fixas)
        adicionarUsuario("admin", "123");
        adicionarUsuario("gustavo", "abc123");
        adicionarUsuario("maria", "senhaSegura");
    }

    private void adicionarUsuario(String nome, String senhaPura) {
        String hash = hashService.gerarHashSHA256(senhaPura);
        usuarios.put(nome, new Usuario(nome, hash));
        logger.info("Usuário adicionado ao repositório: " + nome);
    }

    public Usuario buscarPorNome(String nome) {
        return usuarios.get(nome);
    }
}
