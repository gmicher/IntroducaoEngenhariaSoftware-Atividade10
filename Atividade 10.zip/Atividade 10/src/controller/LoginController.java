package controller;

import service.AutenticadorService;
import util.ValidadorEntrada;
import util.EntradaInvalidaException;

import java.util.logging.Logger;

public class LoginController {

    private static final Logger logger = Logger.getLogger(LoginController.class.getName());

    private final ValidadorEntrada validador = new ValidadorEntrada();
    private final AutenticadorService autenticador = new AutenticadorService();

    public void processarLogin(String usuario, String senha) throws EntradaInvalidaException {
        logger.info("Processando login para o usuário: " + usuario);

        validador.validar(usuario, senha);
        boolean autenticado = autenticador.autenticar(usuario, senha);

        if (autenticado) {
            System.out.println("✅ Bem-vindo, " + usuario + "!");
            logger.info("Login bem-sucedido para o usuário: " + usuario);
        } else {
            System.out.println("❌ Usuário ou senha incorretos.");
            logger.warning("Tentativa de login falhou para o usuário: " + usuario);
        }
    }
}
