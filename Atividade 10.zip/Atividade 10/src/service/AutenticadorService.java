package service;

import model.Usuario;
import repository.UsuarioRepositorio;

import java.util.logging.Logger;

public class AutenticadorService {

    private static final Logger logger = Logger.getLogger(AutenticadorService.class.getName());

    private final UsuarioRepositorio repositorio = new UsuarioRepositorio();
    private final HashService hashService = new HashService();

    public boolean autenticar(String nomeUsuario, String senhaDigitada) {
        logger.info("Iniciando autenticação para: " + nomeUsuario);

        Usuario usuario = repositorio.buscarPorNome(nomeUsuario);

        if (usuario == null) {
            logger.warning("Usuário não encontrado: " + nomeUsuario);
            return false;
        }

        String hashDigitado = hashService.gerarHashSHA256(senhaDigitada);
        boolean valido = usuario.getSenhaHash().equals(hashDigitado);

        if (valido) {
            logger.info("Autenticação bem-sucedida para: " + nomeUsuario);
        } else {
            logger.warning("Senha incorreta para: " + nomeUsuario);
        }

        return valido;
    }
}
