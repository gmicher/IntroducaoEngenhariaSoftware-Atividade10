package service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Logger;

public class HashService {

    private static final Logger logger = Logger.getLogger(HashService.class.getName());

    public String gerarHashSHA256(String texto) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(texto.getBytes());
            StringBuilder hexString = new StringBuilder();

            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            logger.fine("Hash gerado com sucesso para entrada.");
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            logger.severe("Erro ao gerar hash SHA-256: " + e.getMessage());
            throw new RuntimeException("Algoritmo SHA-256 não disponível.", e);
        }
    }
}
