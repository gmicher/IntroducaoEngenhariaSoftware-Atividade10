package util;

public class ValidadorEntrada {

    public void validar(String usuario, String senha) throws EntradaInvalidaException {
        if (usuario == null || usuario.isBlank()) {
            throw new EntradaInvalidaException("O nome de usuário não pode estar vazio.");
        }
        if (senha == null || senha.isBlank()) {
            throw new EntradaInvalidaException("A senha não pode estar vazia.");
        }
    }
}
